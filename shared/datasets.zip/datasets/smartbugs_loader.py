"""
Loader for the SmartBugs Curated dataset.

Ground truth is encoded entirely in the folder name: every .sol file
inside a folder IS an instance of that vulnerability class.  Only the
three folders that map to our canonical classes are loaded; the rest
are silently skipped.

Usage
-----
    from shared.datasets.smartbugs_loader import load_smartbugs
    ground_truths = load_smartbugs()          # uses default dataset path
    ground_truths = load_smartbugs(root)      # explicit path
"""

from pathlib import Path
from typing import Optional

from shared.core.schema import GroundTruth, Vulnerability, VULNERABILITY_CLASSES

# SmartBugs folder name  →  canonical vulnerability class
# Folders not listed here are skipped (not in our evaluation scope).
FOLDER_TO_CLASS: dict[str, str] = {
    "reentrancy":      "reentrancy",
    "access_control":  "access_control",
    "time_manipulation": "timestamp_dependency",
}

# Default location relative to this file's directory.
_DEFAULT_DATASET = Path(__file__).parent / "smartbugs-curated" / "dataset"


def _canonical_class(folder_name: str) -> Optional[str]:
    """Return the canonical class for a SmartBugs folder, or None to skip."""
    return FOLDER_TO_CLASS.get(folder_name)


def load_smartbugs(dataset_root: Optional[Path] = None) -> list[GroundTruth]:
    """Load all in-scope contracts from SmartBugs Curated.

    Parameters
    ----------
    dataset_root:
        Path to the ``dataset/`` directory that contains the per-class
        sub-folders.  Defaults to the bundled ``smartbugs-curated/dataset/``
        directory next to this file.

    Returns
    -------
    list[GroundTruth]
        One entry per .sol file found in a mapped folder, sorted by
        contract_id for reproducibility.
    """
    root = Path(dataset_root) if dataset_root is not None else _DEFAULT_DATASET

    if not root.exists():
        raise FileNotFoundError(
            f"SmartBugs dataset root not found: {root}\n"
            "Clone it with:\n"
            "  git clone https://github.com/smartbugs/smartbugs-curated "
            "datasets/smartbugs-curated"
        )

    ground_truths: list[GroundTruth] = []

    for folder in sorted(root.iterdir()):
        if not folder.is_dir():
            continue

        vuln_class = _canonical_class(folder.name)
        if vuln_class is None:
            continue  # not in our evaluation scope

        assert vuln_class in VULNERABILITY_CLASSES, (
            f"FOLDER_TO_CLASS maps '{folder.name}' → '{vuln_class}' "
            f"but '{vuln_class}' is not in VULNERABILITY_CLASSES"
        )

        for sol_file in sorted(folder.glob("*.sol")):
            contract_id = f"{folder.name}/{sol_file.name}"
            ground_truths.append(
                GroundTruth(
                    contract_id=contract_id,
                    contract_path=str(sol_file),
                    vulnerabilities=[Vulnerability(vuln_class=vuln_class)],
                )
            )

    return ground_truths


# ---------------------------------------------------------------------------
# Standalone smoke-test
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    gts = load_smartbugs()
    counts: dict[str, int] = {}
    for gt in gts:
        cls = gt.vulnerabilities[0].vuln_class
        counts[cls] = counts.get(cls, 0) + 1

    print(f"Total contracts loaded: {len(gts)}")
    for cls in VULNERABILITY_CLASSES:
        print(f"  {cls}: {counts.get(cls, 0)}")
    print("\nFirst 3 entries:")
    for gt in gts[:3]:
        print(f"  {gt.contract_id}  →  {gt.vulnerabilities[0].vuln_class}")
