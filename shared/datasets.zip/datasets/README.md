# datasets/ — Dataset loaders and data

Turns raw benchmark contracts into `GroundTruth` objects the harness can score
against.

## Files

| File | Purpose |
|---|---|
| `smartbugs_loader.py` | `load_smartbugs()` — loads the in-scope SmartBugs Curated contracts. Ground truth is encoded in the folder name (every `.sol` in `reentrancy/` IS a reentrancy bug, etc.). |
| `smartbugs-curated/` | The cloned SmartBugs Curated dataset (contract sources). |

## Scope & label mapping

Only three SmartBugs folders map to our canonical classes; the rest are
skipped:

| SmartBugs folder | Canonical class | Contracts |
|---|---|---|
| `reentrancy` | `reentrancy` | 31 |
| `access_control` | `access_control` | 18 |
| `time_manipulation` | `timestamp_dependency` | 5 |
| **Total** | | **54** |

## Usage

```python
from datasets.smartbugs_loader import load_smartbugs
ground_truths = load_smartbugs()          # default bundled path
ground_truths = load_smartbugs(some_path) # custom dataset root
```

If the dataset is missing, clone it with:

```bash
git clone https://github.com/smartbugs/smartbugs-curated datasets/smartbugs-curated
```

## Adding another dataset

Write a new loader that returns `list[GroundTruth]` and the rest of the
pipeline works unchanged (this is how SolidiFI would plug in later). The
loaders are intentionally dataset-agnostic from the harness's point of view.
